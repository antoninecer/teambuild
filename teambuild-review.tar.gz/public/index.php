<?php

declare(strict_types=1);

require __DIR__ . '/../app/Support/Database.php';
require __DIR__ . '/../app/Repositories/UserRepository.php';
require __DIR__ . '/../app/Repositories/GameRepository.php';
require __DIR__ . '/../app/Repositories/PoiRepository.php';
require __DIR__ . '/../app/Repositories/InviteRepository.php';
require __DIR__ . '/../app/Repositories/TeamRepository.php';
require __DIR__ . '/../app/Repositories/PlayerRepository.php';
require __DIR__ . '/../app/Controllers/Admin/AuthController.php';
require __DIR__ . '/../app/Controllers/Admin/GameController.php';
require __DIR__ . '/../app/Controllers/Admin/PoiController.php';
require __DIR__ . '/../app/Controllers/Admin/InviteController.php';
require __DIR__ . '/../app/Controllers/Player/PlayerController.php';

use App\Controllers\Admin\AuthController;
use App\Controllers\Admin\GameController;
use App\Controllers\Admin\PoiController;
use App\Controllers\Admin\InviteController;
use App\Controllers\Player\PlayerController;

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$method = $_SERVER['REQUEST_METHOD'];

if ($uri === '/' || $uri === '') {
    header('Location: /admin/login');
    exit;
}

if ($uri === '/admin/login' && $method === 'GET') {
    (new AuthController())->showLogin();
    exit;
}

if ($uri === '/admin/login' && $method === 'POST') {
    (new AuthController())->login();
    exit;
}

if ($uri === '/admin/logout' && $method === 'POST') {
    (new AuthController())->logout();
    exit;
}

if ($uri === '/admin/games' && $method === 'GET') {
    (new GameController())->index();
    exit;
}

if ($uri === '/admin/games/create' && $method === 'GET') {
    (new GameController())->createForm();
    exit;
}

if ($uri === '/admin/games' && $method === 'POST') {
    (new GameController())->store();
    exit;
}

if ($method === 'GET' && preg_match('#^/admin/games/(\d+)$#', $uri, $matches)) {
    (new GameController())->show((int) $matches[1]);
    exit;
}

// POI routes
if ($method === 'GET' && preg_match('#^/admin/games/(\d+)/pois$#', $uri, $matches)) {
    (new PoiController())->index((int) $matches[1]);
    exit;
}

if ($method === 'GET' && preg_match('#^/admin/games/(\d+)/pois/create$#', $uri, $matches)) {
    (new PoiController())->createForm((int) $matches[1]);
    exit;
}

if ($method === 'POST' && preg_match('#^/admin/games/(\d+)/pois$#', $uri, $matches)) {
    (new PoiController())->store((int) $matches[1]);
    exit;
}

if ($method === 'GET' && preg_match('#^/admin/pois/(\d+)/edit$#', $uri, $matches)) {
    (new PoiController())->editForm((int) $matches[1]);
    exit;
}

if ($method === 'POST' && preg_match('#^/admin/pois/(\d+)$#', $uri, $matches)) {
    (new PoiController())->update((int) $matches[1]);
    exit;
}

if ($method === 'POST' && preg_match('#^/admin/pois/(\d+)/delete$#', $uri, $matches)) {
    (new PoiController())->delete((int) $matches[1]);
    exit;
}

// Invite routes
if ($method === 'GET' && preg_match('#^/admin/games/(\d+)/invites$#', $uri, $matches)) {
    (new InviteController())->index((int) $matches[1]);
    exit;
}

if ($method === 'GET' && preg_match('#^/admin/games/(\d+)/invites/create$#', $uri, $matches)) {
    (new InviteController())->createForm((int) $matches[1]);
    exit;
}

if ($method === 'POST' && preg_match('#^/admin/games/(\d+)/invites$#', $uri, $matches)) {
    (new InviteController())->store((int) $matches[1]);
    exit;
}

if ($method === 'POST' && preg_match('#^/admin/invites/(\d+)/delete$#', $uri, $matches)) {
    (new InviteController())->delete((int) $matches[1]);
    exit;
}

// Player routes
if ($method === 'GET' && preg_match('#^/game/([^/]+)$#', $uri, $matches)) {
    (new PlayerController())->showGame($matches[1]);
    exit;
}

if ($method === 'POST' && preg_match('#^/game/([^/]+)/register$#', $uri, $matches)) {
    (new PlayerController())->register($matches[1]);
    exit;
}

// API routes for active players
if ($method === 'POST' && $uri === '/api/player/location') {
    (new PlayerController())->updateLocation();
    exit;
}

if ($method === 'POST' && $uri === '/api/player/help') {
    (new PlayerController())->requestHelp();
    exit;
}

http_response_code(404);
echo '404 Not Found';
