<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrace do hry - <?php echo htmlspecialchars($game['name']); ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <style>
        body { font-family: sans-serif; padding: 20px; max-width: 400px; margin: 0 auto; }
        .error { color: red; background: #fee; padding: 10px; border: 1px solid red; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; }
        input[type="text"] { width: 100%; padding: 8px; box-sizing: border-box; }
        button { padding: 10px 15px; background: #007bff; color: white; border: none; cursor: pointer; width: 100%; }
        button:hover { background: #0056b3; }
    </style>
</head>
<body>
    <h1><?php echo htmlspecialchars($game['name']); ?></h1>
    <p>Zadej svoji přezdívku pro vstup do hry.</p>

    <?php if (isset($error)): ?>
        <div class="error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form action="/game/<?php echo htmlspecialchars($game['slug']); ?>/register" method="POST">
        <div class="form-group">
            <label for="nickname">Přezdívka:</label>
            <input type="text" id="nickname" name="nickname" value="<?php echo htmlspecialchars($_POST['nickname'] ?? ''); ?>" required autofocus>
        </div>

        <div class="form-group">
            <label for="invite_code">Invite kód (volitelný):</label>
            <input type="text" id="invite_code" name="invite_code" value="<?php echo htmlspecialchars($inviteCode ?? ''); ?>">
        </div>

        <button type="submit">Vstoupit do hry</button>
    </form>
</body>
</html>
